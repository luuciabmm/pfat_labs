package GeneratedCodeLib;

import java.util.Vector;

import Errors.*;
import java.util.Set;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.HashSet;


public class InSet extends IntSetA {
    private Set<Integer> set;

    public InSet() {
        super();
        set = new HashSet<>();
    }

    public InSet(Vector<Integer> v) {
        super(v);
        set = new HashSet<>(v);
    }
    
    @Override
    public InSet unionSet(IntSetA is) {
        if (!(is instanceof InSet)) {
            throw new IllegalArgumentException("Union requires an instance of InSet");
        }
        InSet otherSet = (InSet) is;
        InSet union = new InSet();
        union.set.addAll(this.set);
        union.set.addAll(otherSet.set);
        return union;
    }

    @Override
    public InSet intersectionSet(IntSetA is) {
        if (!(is instanceof InSet)) {
            throw new IllegalArgumentException("Intersection requires an instance of InSet");
        }
        InSet otherSet = (InSet) is;
        InSet intersection = new InSet();
        intersection.set.addAll(this.set);
        intersection.set.retainAll(otherSet.set);
        return intersection;
    }

    @Override
    public InSet setDif(IntSetA is) {
        if (!(is instanceof InSet)) {
            throw new IllegalArgumentException("Set difference requires an instance of InSet");
        }
        InSet otherSet = (InSet) is;
        InSet difference = new InSet();
        difference.set.addAll(this.set);
        difference.set.removeAll(otherSet.set);
        return difference;
    }

    @Override
    public int lowestElem() throws EmptySetException {
        if (set.isEmpty()) {
            throw new EmptySetException();
        }
        return set.stream().min(Integer::compareTo).get();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        InSet inSet = (InSet) obj;
        return set.equals(inSet.set);
    }

    public InSet union(InSet other) {
        InSet result = new InSet();
        result.set.addAll(this.set);
        result.set.addAll(other.set);
        return result;
    }

    public InSet intersec(InSet other) {
        InSet result = new InSet();
        result.set.addAll(this.set);
        result.set.retainAll(other.set);
        return result;
    }

    public void add(Integer element) {
        set.add(element);
    }

    public int card() {
        return set.size();
    }

    public boolean belongsTo(int i) {
        return set.contains(i);
    }

    public static boolean belongsToStatic(InSet set, int element) {
        return set.set.contains(element);
    }

    public boolean isEmpty(){
        return this.set.isEmpty();
    } 
    
    
}
