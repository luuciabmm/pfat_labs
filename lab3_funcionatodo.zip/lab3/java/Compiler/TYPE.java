package Compiler;

public class TYPE {

    public static final int t_int = 1;
    public static final int t_bool = 2;
    public static final int t_inset = 3;
    public static final int t_void = 4;

    public static String typString(int t){
        if(t == t_int){
            return "int";
        }
        if(t == t_bool){
            return "bool";
        }
        if(t == t_inset){
            return "t_inset";
        }
        return "void";    
    }
}

