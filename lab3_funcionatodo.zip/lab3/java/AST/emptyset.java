package AST;

import Errors.*;
import Compiler.TYPE;

import java.io.BufferedWriter;
import java.io.IOException;

public class emptyset implements Exp {
    //private boolean checkIfEmpty;

    public int computeTyp() throws CompilerExc {
        return TYPE.t_inset;
    }

    // public emptyset(boolean checkIfEmpty) {
    //     this.checkIfEmpty = checkIfEmpty;
    // }

    // public void generateCode(BufferedWriter w) throws IOException {
    //         w.write("new InSet(new Vector<>())");
        
    //         // Si checkIfEmpty es verdadero y el conjunto está vacío, generar código para verificar si el conjunto está vacío
    //         if (checkIfEmpty) {
    //             w.write(".isEmpty()");
    //         } else {
    //             w.write("new InSet(new Vector<>())");
    //         }
    // }

    public void generateCode(BufferedWriter w) throws IOException {
        w.write("new InSet()");
    }
    
}   
