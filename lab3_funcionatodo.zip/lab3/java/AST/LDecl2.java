package AST;

import Errors.*;

import java.io.BufferedWriter;
import java.io.IOException;

public class LDecl2 implements LDecl {
    private final Decl d;
    private final LDecl ld;

    public LDecl2(Decl d, LDecl ld){
        this.d = d;
        this.ld = ld;
    }

    public Decl getDecl(){
        return d;
    }

    public LDecl getLDecl(){
        return ld;
    }

    public void computeAh1() throws CompilerExc{
        d.computeAh1();
        ld.computeAh1();
    }

    public void generateCode(BufferedWriter w, int indentLevel) throws IOException {
        for (int i = 0; i < indentLevel; i++) {
            w.write(""); // Agrega 4 espacios para cada nivel de indentación
        }
        d.generateCode(w, indentLevel);
        w.write(";");
        w.newLine();
        ld.generateCode(w, indentLevel); // Mantén el mismo nivel de indentación para el resto de las declaraciones
    }
}