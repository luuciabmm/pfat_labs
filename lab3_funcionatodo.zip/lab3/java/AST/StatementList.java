package AST;

import java.io.BufferedWriter;

import Errors.*;

import java.io.IOException;

public interface StatementList {
    public int computeStTyp() throws CompilerExc;
    public void generateCode(BufferedWriter w, int indentLevel) throws IOException;
}




