package AST;

import Errors.*;
import Compiler.SymbolTable;
import java.io.BufferedWriter;
import java.io.IOException;

public class IDENT implements Exp {
    private final String i;

    public IDENT(String i){
        this.i = i;
    }

    public String getId(){
        return i;
    }

    public int computeTyp() throws CompilerExc{
        // Fetch and return the type associated with the identifier from the symbol table
        return SymbolTable.getType(i);
    }

    public void generateCode(BufferedWriter w) throws IOException {
        w.write(i);  // Simply write the identifier's name to the output stream
    }
}
