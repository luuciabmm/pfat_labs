package AST;
import Errors.*;
import Compiler.TYPE;

import java.io.BufferedWriter;
import java.io.IOException;

public class CLOG implements Exp {
    private final boolean clg;

    public CLOG(boolean clg) {
        this.clg = clg;
    }

    public boolean getCLog() {
        return clg;
    }
    
    public int computeTyp() throws CompilerExc{
        return TYPE.t_bool;
    }

    public void generateCode(BufferedWriter w) throws IOException{
        w.write("" + clg);
    }
}
