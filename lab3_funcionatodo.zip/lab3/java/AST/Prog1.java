package AST;
import Errors.*;

import java.io.BufferedWriter;
import java.io.IOException;

public class Prog1 implements Prog {
    private final String i;
    private final LDecl ld;
    private final Body b;

    public Prog1(String i, LDecl ld, Body b){
        this.i=i;
        this.ld=ld;
        this.b=b;
    }

    public String getIdent(){
        return i;
    }

    public LDecl getLDecl(){
        return ld;
    }

    public Body getBody(){
        return b;
    }

    public void computeAh1() throws CompilerExc{
        ld.computeAh1();
    }
    public void computeTyp() throws CompilerExc{
        b.computeStTyp();
    }
    public void generateCode(BufferedWriter w, int indentLevel) throws IOException {
        for (int i = 0; i < indentLevel; i++) {
            w.write(" ");
        }
        w.write("  public static void execute() throws EmptySetException {\n");
        //w.newLine();
        // Generate code for declarations
        ld.generateCode(w, indentLevel + 2);
        w.newLine();
        // Generate code for the body of the program
        b.generateCode(w, indentLevel + 2);
        w.newLine();
        for (int i = 0; i < indentLevel; i++) {
            w.write(" ");
        }
        w.write("  }\n");
    }
}
