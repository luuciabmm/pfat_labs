package AST;

import Errors.*;
import Compiler.SymbolTable;
import Compiler.TYPE;

import java.io.BufferedWriter;
import java.io.IOException;

public class Statement2 implements Statement {
    private final String i;

    public Statement2 (String i){
        this.i = i;
    }

    public String getI() {
        return i;
    }  

    public int computeStTyp() throws CompilerExc{
        int statement;
        statement=SymbolTable.getType(i);

        if(statement == TYPE.t_int){
            return TYPE.t_void;
        }else{
            throw new TypeExc("ERROR");
        }
        
    }

    public void generateCode(BufferedWriter w, int indentLevel) throws IOException {
        for (int i = 0; i < indentLevel; i++) {
            w.write("  ");
        }
        w.write("System.out.println(\"El valor de la variable " + i + " es: \" + " + i + ");\n");   //error, mirar que se imprima el valor de la variable
    }
    
}

