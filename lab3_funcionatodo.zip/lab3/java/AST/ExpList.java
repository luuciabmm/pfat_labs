package AST;

import java.io.BufferedWriter;
import java.io.IOException;

import Errors.*;

public interface ExpList {
    public int computeTyp() throws CompilerExc;

    public void generateCode(BufferedWriter w) throws IOException;
}
