package AST;

import Errors.*;
import Compiler.TYPE;

import java.io.BufferedWriter;
import java.io.IOException;

public class lowestElem implements Exp {
    private final Exp e1;

    public lowestElem(Exp e1) {
        this.e1 = e1;
    }

    public Exp getE1() {
        return e1;
    }

    public int computeTyp() throws CompilerExc{
        int Elem;
        Elem = e1.computeTyp();

        if(Elem == TYPE.t_inset){
            return TYPE.t_int;
        }else{
            throw new TypeExc("ERROR");
        }
    }

    public void generateCode(BufferedWriter w) throws IOException {
        e1.generateCode(w);
        w.write(".lowestElem()");
    } 

}
