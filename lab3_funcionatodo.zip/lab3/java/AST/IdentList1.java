package AST;

import Errors.*;
import Compiler.SymbolTable;

import java.io.BufferedWriter;
import java.io.IOException;

//import Compiler.TYPE;


public class IdentList1 implements IdentList{
    private final String i;
    private int ah1;

    public IdentList1(String i){
        this.i = i;
    }

    public String getI() {
        return i;
    }

    public void computeAh1(int t) throws CompilerExc{
        this.ah1=t;
        SymbolTable.newEntry(this.i, this.ah1);
    }

    public void generateCode(BufferedWriter w, int indentLevel) throws IOException {
        for (int i = 0; i < indentLevel; i++) {
            w.write(""); // Agrega 4 espacios para cada nivel de indentación
        }
        w.write(i);
    }

    
}
