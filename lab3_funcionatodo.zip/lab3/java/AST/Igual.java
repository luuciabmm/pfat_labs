package AST;

import Errors.*;
import Compiler.TYPE;

import java.io.BufferedWriter;
import java.io.IOException;

public class Igual implements Exp {
    private final Exp e1;
    private final Exp e2;

    int igual1;
    int igual2;

    public Igual(Exp e1, Exp e2) {
        this.e1 = e1;
        this.e2 = e2;
    }

    public Exp getE1() {
        return e1;
    }

    public Exp getE2() {
        return e2;
    }

    public int computeTyp() throws CompilerExc{
        igual1 = e1.computeTyp();
        igual2 = e2.computeTyp();
    
        if((igual1 == TYPE.t_bool) == (igual2 == TYPE.t_bool)) {
            return TYPE.t_bool;
        } else {
            throw new TypeExc("ERROR");
        }
    }


    public void generateCode(BufferedWriter w) throws IOException {
        if ((igual1 == TYPE.t_int) && (igual2 == TYPE.t_int)){
            w.write("(");
            e1.generateCode(w);
            w.write(" == ");
            e2.generateCode(w);
            w.write(")");
        } else if ((igual1 == TYPE.t_inset) && (igual2 == TYPE.t_inset)) {
            // Asumimos que podemos identificar si e2 es un conjunto vacío
            if (e2 instanceof emptyset) {
                e1.generateCode(w);
                w.write(".isEmpty()");
            } else {
                e1.generateCode(w);
                w.write(".equals(");
                e2.generateCode(w);
                w.write(")");
            }
        }
    }  
}



