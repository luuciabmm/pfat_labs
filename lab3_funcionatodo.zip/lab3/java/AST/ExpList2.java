package AST;

import Errors.*;
import Compiler.TYPE;

import java.io.BufferedWriter;
import java.io.IOException;

public class ExpList2 implements ExpList {
    private final Exp e1;
    private final ExpList elt;

    public ExpList2(Exp e1, ExpList elt){
        this.e1 = e1;
        this.elt = elt;
    }

    public Exp getE1() {
        return e1;
    }

    public ExpList getELt() {
        return elt;
    }

    public int computeTyp() throws CompilerExc{
        int expresion, expresionlist;
        expresion = e1.computeTyp();
        expresionlist = elt.computeTyp();

        if((expresion == TYPE.t_int) && (expresionlist == TYPE.t_void)){
            return TYPE.t_void;
        }else{
            throw new TypeExc("ERROR");
        }
    }
    
    public void generateCode(BufferedWriter w) throws IOException{
        e1.generateCode(w);  // Generate code for the first expression
        w.write(", ");       // Delimit expressions with a comma
        elt.generateCode(w); // Recursively generate code for the rest of the list
    }

}
