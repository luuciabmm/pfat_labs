package AST;

import Errors.*;
import Compiler.TYPE;

import java.io.BufferedWriter;
import java.io.IOException;

public class Mul implements Exp {
        private final Exp e1;
        private final Exp e2;
    
        public Mul(Exp e1, Exp e2) {
            this.e1 = e1;
            this.e2 = e2;
        }

        public Exp getE1() {
            return e1;
        }

        public Exp getE2() {
            return e2;
        }

        public int computeTyp() throws CompilerExc{
            int mul1, mul2;
            mul1 = e1.computeTyp();
            mul2 = e2.computeTyp();
    
            if((mul1 == TYPE.t_int) && (mul2 == TYPE.t_int)){
                return TYPE.t_int;
            }else {
                throw new TypeExc("ERROR");
            }
    
        }
        
        public void generateCode(BufferedWriter w) throws IOException{
            w.write("(");
            e1.generateCode(w);
            w.write("*");
            e2.generateCode(w);
            w.write(")");
        }


    
}
