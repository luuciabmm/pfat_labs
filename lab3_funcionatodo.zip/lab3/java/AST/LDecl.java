package AST;

import Errors.*;

import java.io.BufferedWriter;
import java.io.IOException;

public interface LDecl {
    public void computeAh1() throws CompilerExc;
    public void generateCode(BufferedWriter w, int identLevel) throws IOException;

}
