package AST;

import Errors.*;

import java.io.BufferedWriter;
import java.io.IOException;

import Compiler.TYPE;


public class Decl1 implements Decl {
    private final int t;
    private final IdentList il;

    public Decl1(int t, IdentList il){
        this.t = t;
        this.il = il;
    }

    public int getType(){
        return t;
    }

    public IdentList getIdentList() {
        return il;
    }

    public void computeAh1() throws CompilerExc{
        int ah1 = this.t;
        il.computeAh1(ah1);
    }

    public void generateCode(BufferedWriter w, int indentLevel) throws IOException {
        StringBuilder indentation = new StringBuilder();
        for (int i = 0; i < indentLevel; i++) {
            indentation.append("  "); // 4 spaces for one indentation level
        }
    
        String typedecl = "";
        switch (t) {
            case TYPE.t_int:
                typedecl = "int";
                break;
            case TYPE.t_bool:
                typedecl = "boolean";
                break;
            case TYPE.t_inset:
                typedecl = "InSet";
                break;
            default:
                break; // or handle more types as needed
        }
        w.write(indentation.toString() + typedecl + " ");
        il.generateCode(w, indentLevel + 1); // Increase the indent level for the next line
    }


}
