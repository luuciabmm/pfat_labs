package AST;

import Errors.*;
import java.io.BufferedWriter;
import java.io.IOException;

public class Prog2 implements Prog {
    private final String i;
    private final Body b;

    public Prog2(String i, Body b){
        this.i = i;
        this.b = b;
    }

    public String getIdent(){
        return i;
    }

    public Body getBody(){
        return b;
    }

    public void computeAh1() throws CompilerExc{
        // Potentially empty if no header processing is needed
    }
    
    public void computeTyp() throws CompilerExc{
        // Ensures the body's structural and type integrity
        b.computeStTyp();
    }

    public void generateCode(BufferedWriter w, int indentLevel) throws IOException {
        for (int i = 0; i < indentLevel; i++) {
            w.write("  "); // 4 espacios por nivel de indentación
        }
        w.write("  public static void execute() throws EmptySetException {\n");
        w.newLine();
        
        // Increase the indentLevel for nested code
        //indentLevel += 1;
        
        for (int i = 0; i < indentLevel; i++) {
            w.write(" "); // 4 espacios por nivel de indentación
        }
        // Here, we might have set up or preliminary statements if needed
        w.newLine();
        
        for (int i = 0; i < indentLevel; i++) {
            w.write("    "); // 4 espacios por nivel de indentación
        }
        // Generate the body of the program
        b.generateCode(w, indentLevel);
        w.newLine();
        
        for (int i = 0; i < indentLevel; i++) {
            w.write("    "); // 4 espacios por nivel de indentación
        }
        w.write("  }\n");
    }
}
