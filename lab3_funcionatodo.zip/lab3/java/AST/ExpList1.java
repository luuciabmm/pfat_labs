package AST;

import Errors.*;
import Compiler.TYPE;
import java.io.BufferedWriter;
import java.io.IOException;

public class ExpList1 implements ExpList {
    private final Exp e1;

    public ExpList1(Exp e1) {
        this.e1 = e1;
    }

    public Exp getE1() {
        return e1;
    }

    public void computeAh1() throws CompilerExc{

    }
    
    public int computeTyp() throws CompilerExc{
        int expresion;
        expresion = e1.computeTyp();

        if(expresion == TYPE.t_int){
            return TYPE.t_void;
        }else{
            throw new TypeExc("ERROR");
        }
    }
    
    public void generateCode(BufferedWriter w) throws IOException {
        e1.generateCode(w);
    }
}
