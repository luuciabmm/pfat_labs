package AST;

import Errors.*;
import Compiler.TYPE;

import java.io.BufferedWriter;
import java.io.IOException;

public class Union implements Exp {
        private final Exp e1;
        private final Exp e2;
    
        public Union(Exp e1, Exp e2) {
            this.e1 = e1;
            this.e2 = e2;
        }

        public Exp getE1() {
            return e1;
        }

        public Exp getE2() {
            return e2;
        }

        public int computeTyp() throws CompilerExc{
            int union1, union2;
            union1 = e1.computeTyp();
            union2 = e2.computeTyp();

            if((union1 == TYPE.t_inset) && (union2 == TYPE.t_inset)){
                return TYPE.t_inset;
            }else {
                throw new TypeExc("ERROR");
            }
            
        }

        public void generateCode(BufferedWriter w) throws IOException{
            e1.generateCode(w);
            w.write(".unionSet(");
            e2.generateCode(w);
            w.write(")");
        }

    

    
}
