package AST;

import Errors.*;
import Compiler.TYPE;

import java.io.BufferedWriter;
import java.io.IOException;


public class Inside implements Exp {
    private final Exp e1;
    private final Exp e2;
    int insd1, insd2;

    public Inside(Exp e1, Exp e2) {
        this.e1 = e1;
        this.e2 = e2;
    }

    public Exp getE1() {
        return e1;
    }

    public int computeTyp() throws CompilerExc{
        
        insd1 = e1.computeTyp();
        insd2 = e2.computeTyp();

        if((insd1 == TYPE.t_int) && (insd2 == TYPE.t_inset)){
            return TYPE.t_bool;
        }else {
            throw new TypeExc("ERROR");
        }
    }

    public void generateCode(BufferedWriter w) throws IOException{
        w.write("InSet.belongsToStatic(");
        e2.generateCode(w); // Primero el conjunto (InSet)
        w.write(", ");
        e1.generateCode(w); // Luego el elemento (int)
        w.write(")");
        
        /* 
        if ((insd1 == TYPE.t_int) && (insd2 == TYPE.t_int)){
            w.write("(");
            e1.generateCode(w);
            w.write(" == ");
            e2.generateCode(w);
            w.write(")");
        }else if((insd1 == TYPE.t_inset) && (insd2 == TYPE.t_inset)){
            e1.generateCode(w);
            w.write(".belongsTo(");
            e2.generateCode(w);
            w.write(")");
        }
        */
    }
    
}
