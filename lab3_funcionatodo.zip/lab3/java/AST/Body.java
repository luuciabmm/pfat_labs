package AST;
import Errors.*;

import java.io.BufferedWriter;
import java.io.IOException;

public class Body{
    private final StatementList sl;
    
    public Body(StatementList sl){
        this.sl = sl;
    }

    public StatementList getSl() {
        return sl;
    }

    public int computeStTyp() throws CompilerExc{
        return sl.computeStTyp();
    }

    public void generateCode(BufferedWriter w, int indentLevel) throws IOException {
        for (int i = 0; i < indentLevel; i++) {
            w.write("    "); // 4 espacios por nivel de indentación
        }
        w.newLine();
        sl.generateCode(w, indentLevel);
    }
} 
    
    