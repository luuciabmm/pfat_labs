package AST;

import Errors.*;

import java.io.BufferedWriter;
import java.io.IOException;


public class Parentesis implements Exp {
    public final Exp e1;

    public Parentesis(Exp e1) {
        this.e1 = e1;
    }

    public int computeTyp() throws CompilerExc {
        return e1.computeTyp();
    }

    public void generateCode(BufferedWriter w) throws IOException{
        w.write("(");
        e1.generateCode(w);
        w.write(")");
    }
}
