package AST;

import Errors.*;
import Compiler.TYPE;

import java.io.BufferedWriter;
import java.io.IOException;

public class And implements Exp {
    private final Exp e1;
    private final Exp e2;

    public And(Exp e1, Exp e2) {
        this.e1 = e1;
        this.e2 = e2;
    }

    public Exp getE1() {
        return e1;
    }

    public Exp getE2() {
        return e2;
    }

    public int computeTyp() throws CompilerExc {
        int and1, and2;
        and1 = e1.computeTyp();
        and2 = e2.computeTyp();

        if((and1 == TYPE.t_bool) && (and2 == TYPE.t_bool)) {
            return TYPE.t_bool;
        } else {
            throw new TypeExc("ERROR");
        }
    }

    public void generateCode(BufferedWriter w) throws IOException{
        w.write("(");
        e1.generateCode(w);
        w.write("&&");
        e2.generateCode(w);
        w.write(")");
    }
    
} 