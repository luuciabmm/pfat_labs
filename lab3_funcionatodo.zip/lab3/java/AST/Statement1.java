package AST;

import Errors.*;
import Compiler.TYPE;
import Compiler.SymbolTable;

import java.io.BufferedWriter;
import java.io.IOException;

public class Statement1 implements Statement {
    private final String i;
    private final Exp e1;

    public Statement1(String i, Exp e1){
        this.i = i;
        this.e1 = e1;
    }

    public String getI() {
        return i;
    }

    public Exp getE1() {
        return e1;
    }
    
    public int computeStTyp() throws CompilerExc{
        int statement1, statement2;
        statement1=SymbolTable.getType(i);
        statement2=e1.computeTyp();

        if(statement1 == statement2){
            return TYPE.t_void;
        }else{
            throw new TypeExc("ERROR");
        }
    }

    public void generateCode(BufferedWriter w, int indentLevel) throws IOException {
        for (int i = 0; i < indentLevel; i++) {
            w.write("  "); 
        }
        w.write(i + " = ");
        e1.generateCode(w);
        w.write(";");
    }
    
}
