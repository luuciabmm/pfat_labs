package AST;

import Errors.*;
import Compiler.TYPE;

import java.io.BufferedWriter;
import java.io.IOException;

public class StatementList2 implements StatementList{
    private final Statement st;
    private final StatementList sl;

    public StatementList2(Statement st, StatementList sl){
        this.st = st;
        this.sl = sl;
    }

    public Statement getSt() {
        return st;
    }

    public StatementList getSl() {
        return sl;
    }

    public void computeAh1() throws CompilerExc{

    }
    public int computeStTyp() throws CompilerExc{
        int statement1, statement2;
        statement1 = st.computeStTyp();
        statement2 = sl.computeStTyp();

        if((statement1 == TYPE.t_void) && (statement2 == TYPE.t_void)) {
            return TYPE.t_void;
        } else {
            throw new TypeExc("ERROR");
    }  
    
    }
    
    public void generateCode(BufferedWriter w, int indentLevel) throws IOException {
        for (int i = 0; i < indentLevel; i++) {
            w.write("    "); // Agrega 4 espacios para cada nivel de indentación
        }
        // Generate code for the first statement
        st.generateCode(w, indentLevel);
        // Generate code for the rest of the statement list
        w.newLine();
        sl.generateCode(w, indentLevel);
    }
}
