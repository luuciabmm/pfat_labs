package AST;

import Errors.*;
import Compiler.TYPE;

import java.io.BufferedWriter;
import java.io.IOException;


public class Intersec implements Exp {
        private final Exp e1;
        private final Exp e2;
    
        public Intersec(Exp e1, Exp e2) {
            this.e1 = e1;
            this.e2 = e2;
        }

        public Exp getE1() {
            return e1;
        }

        public Exp getE2() {
            return e2;
        }

        public int computeTyp() throws CompilerExc{
            int inter1, inter2;
            inter1 = e1.computeTyp();
            inter2 = e2.computeTyp();

            if((inter1 == TYPE.t_inset) && (inter2 == TYPE.t_inset)){
                return TYPE.t_inset;
            }else {
                throw new TypeExc("ERROR");
            }
            
        }
    
    public void generateCode(BufferedWriter w) throws IOException {
        e1.generateCode(w);
        w.write(".intersec(");
        e2.generateCode(w);
        w.write(")");
    }
    
}
