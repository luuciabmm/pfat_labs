package AST;

import Errors.*;
import Compiler.TYPE;

import java.io.BufferedWriter;
import java.io.IOException;

public class Statement5 implements Statement {
    private final Exp e1;
    private final StatementList sl;

    public Statement5(Exp e1, StatementList sl){
        this.e1 = e1;
        this.sl =sl;
    }

    public Exp getE1() {
        return e1;
    }

    public StatementList getSl() {
        return sl;
    }


    public int computeStTyp() throws CompilerExc{
        int statement1, statement2;
        statement1 = e1.computeTyp();
        statement2 = sl.computeStTyp();

        if((statement1 == TYPE.t_bool) && (statement2 == TYPE.t_void)){
            return TYPE.t_void;
        }else{
            throw new TypeExc("ERROR");
        }
    }    

    public void generateCode(BufferedWriter w, int indentLevel) throws IOException {
        for (int i = 0; i < indentLevel; i++) {
            w.write("  "); 
        }
        w.newLine();
        w.write("    while (");
        e1.generateCode(w); // Generate the condition code
        w.write(") {\n");
        sl.generateCode(w, indentLevel); // Generate the code for the statement list within the block with increased indent level
        w.newLine();
        w.write("    }\n");
    }
}


