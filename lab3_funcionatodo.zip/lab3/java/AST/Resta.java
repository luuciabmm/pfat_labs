package AST;

import Errors.*;
import Compiler.TYPE;

import java.io.BufferedWriter;
import java.io.IOException;

public class Resta implements Exp {
        private final Exp e1;
        private final Exp e2;
        int resta1, resta2;
    
        public Resta(Exp e1, Exp e2) {
            this.e1 = e1;
            this.e2 = e2;
        }

        public Exp getE1() {
            return e1;
        }

        public Exp getE2() {
            return e2;
        }

        public int computeTyp() throws CompilerExc{
            resta1 = e1.computeTyp();
            resta2 = e2.computeTyp();
        
            if((resta1 == TYPE.t_int) && (resta2 == TYPE.t_int)){
                return TYPE.t_int;
            }else if((resta1 == TYPE.t_inset) && (resta2 == TYPE.t_inset)){
                return TYPE.t_inset;
            }else {
                throw new TypeExc("ERROR");
            }
        
            }

            /* 
            public void generateCode(BufferedWriter w) throws IOException{
                //w.write("(");
                e1.generateCode(w);
                w.write(" - ");
                e2.generateCode(w);
                w.write(")");
            }
            */

            ///////////////COMPROBAR
            public void generateCode(BufferedWriter w) throws IOException {
                if ((resta1 == TYPE.t_int) && (resta2 == TYPE.t_int)){
                    w.write("(");
                    e1.generateCode(w);
                    w.write(" - ");
                    e2.generateCode(w);
                    w.write(")");
                }else if((resta1 == TYPE.t_inset) && (resta2 == TYPE.t_inset)){
                    e1.generateCode(w);
                    w.write(".setDif(");
                    e2.generateCode(w);
                    w.write(")");
                }
            }    

}


    

    