package AST;

import Errors.*;
import Compiler.TYPE;

import java.io.BufferedWriter;
import java.io.IOException;

public class Opuesto implements Exp {
    private final Exp e1;

    public Opuesto(Exp e1) {
        this.e1 = e1;
    }

    public Exp getE1() {
        return e1;
    }

    public int computeTyp() throws CompilerExc{
        int tipo = e1.computeTyp();

        if(tipo == TYPE.t_int){
            return TYPE.t_int;
        } else {
            throw new TypeExc("ERROR");
        }
    }

    public void generateCode(BufferedWriter w) throws IOException{
        w.write("-(");
        e1.generateCode(w);
        w.write(")");
    }
}
