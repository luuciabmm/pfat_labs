package AST;

import java.io.BufferedWriter;
import java.io.IOException;

import Errors.*;

public interface IdentList {

    public void computeAh1(int t) throws CompilerExc;

    public void generateCode(BufferedWriter w, int indentLevel) throws IOException;
    
}
