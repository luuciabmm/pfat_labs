package AST;

import Errors.*;

import java.io.BufferedWriter;
import java.io.IOException;

public interface Statement {
    public int computeStTyp() throws CompilerExc;
    public void generateCode(BufferedWriter w, int indentLevel) throws IOException;
}

