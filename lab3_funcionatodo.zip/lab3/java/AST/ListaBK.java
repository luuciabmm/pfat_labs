package AST;


import Errors.*;
import Compiler.TYPE;

import java.io.BufferedWriter;
import java.io.IOException;


public class ListaBK implements Exp{
    private final ExpList el;

    public ListaBK(ExpList el) {
        this.el = el;
    }

    public ExpList getEL() {
        return el;
    }

    public int computeTyp() throws CompilerExc{
        int lista;
        lista = el.computeTyp();

        if(lista == TYPE.t_void){
            return TYPE.t_inset;
        }else {
            throw new TypeExc("ERROR");
        }
    }

    public void generateCode(BufferedWriter w) throws IOException{
        // Generate code assuming the ExpList el outputs a collection of elements suitable for a Set
        w.write("new InSet(new Vector<>(Arrays.asList(");
        el.generateCode(w);
        w.write(")))");
    }
}
