package AST;

import Errors.*;
import Compiler.TYPE;
import java.io.BufferedWriter;
import java.io.IOException;

public class Not implements Exp {
    private final Exp e1;

    public Not(Exp e1) {
        this.e1 = e1;
    }

    public Exp getE1() {
        return e1;
    }

    public int computeTyp() throws CompilerExc {
        int not = e1.computeTyp();

        if (not == TYPE.t_bool) {
            return TYPE.t_bool;
        } else {
            throw new TypeExc("Type error: Logical NOT operation requires a boolean type.");
        }
    }

    public void generateCode(BufferedWriter w) throws IOException {
        w.write("!(");
        e1.generateCode(w);
        w.write(")");
    }
}
