package AST;

import Errors.*;

import java.io.BufferedWriter;
import java.io.IOException;

public class LDecl1 implements LDecl {
    private final Decl d;

    public LDecl1(Decl d){
        this.d = d;
    }

    public Decl getDecl(){
        return d;
    }

    public void computeAh1() throws CompilerExc{
        d.computeAh1();
    }
    
    public void generateCode(BufferedWriter w, int indentLevel) throws IOException {
        for (int i = 0; i < indentLevel; i++) {
            w.write(""); // Agrega 4 espacios para cada nivel de indentación
        }
        d.generateCode(w, indentLevel);
        w.write(";");
    }
    
}
