package AST;

import Errors.*;

import java.io.BufferedWriter;
import java.io.IOException;

public class StatementList1 implements StatementList{
    private final Statement st;

    public StatementList1(Statement st){
        this.st = st;
    }

    public Statement getSt() {
        return st;
    }
    
    public int computeStTyp() throws CompilerExc{
        return st.computeStTyp();
    }

    public void generateCode(BufferedWriter w, int indentLevel) throws IOException {
        for (int i = 0; i < indentLevel; i++) {
            w.write("    "); // Agrega 4 espacios para cada nivel de indentación
        }
        st.generateCode(w, indentLevel); // Generate the code for the statement
    }
    
}
