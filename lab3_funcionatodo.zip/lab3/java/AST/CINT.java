package AST;
import Errors.*;
import Compiler.TYPE;

import java.io.BufferedWriter;
import java.io.IOException;

public class CINT implements Exp {
    private final int cit;

    public CINT(int cit) {
        this.cit = cit;
    }

    public int getCi() {
        return cit;
    }

    public int computeTyp() throws CompilerExc{
        return TYPE.t_int;
    }

    public void generateCode(BufferedWriter w) throws IOException{
        w.write(""+cit);
    }

}
