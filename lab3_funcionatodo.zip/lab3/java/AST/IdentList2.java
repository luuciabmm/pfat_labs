package AST;

import Compiler.SymbolTable;
import Errors.*;

import java.io.BufferedWriter;
import java.io.IOException;

//import Compiler.TYPE;

public class IdentList2 implements IdentList{
    private final String i;
    private final IdentList il;
    private int ah1;

    public IdentList2(String i, IdentList il){
        this.i = i;
        this.il = il;
    }

    public String getI() {
        return i;
    }

    public IdentList getIl() {
        return il;
    }
    
    public void computeAh1(int t) throws CompilerExc{
        this.ah1 = t;
        il.computeAh1(t);
        SymbolTable.newEntry(i, ah1);

    }

    public void generateCode(BufferedWriter w, int indentLevel) throws IOException {
        for (int i = 0; i < indentLevel; i++) {
            w.write(""); // Agrega 4 espacios para cada nivel de indentación
        }
        w.write(i);
        w.write(", ");
        il.generateCode(w, indentLevel + 1); // Agrega un nivel de indentación adicional para el siguiente elemento
    }
    
    
}
    
