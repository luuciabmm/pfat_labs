package AST;

import Errors.*;
import Compiler.TYPE;
import java.io.BufferedWriter;
import java.io.IOException;

public class Mayor implements Exp {
    private final Exp e1;
    private final Exp e2;

    public Mayor(Exp e1, Exp e2) {
        this.e1 = e1;
        this.e2 = e2;
    }

    public Exp getE1() {
        return e1;
    }

    public Exp getE2() {
        return e2;
    }

    public int computeTyp() throws CompilerExc{
        int mayor1;
        int mayor2;
        mayor1 = e1.computeTyp();
        mayor2 = e2.computeTyp();
    
        if((mayor1 == TYPE.t_int) == (mayor2 == TYPE.t_int)) {
            return TYPE.t_bool;
        } else {
            throw new TypeExc("ERROR");
        }
    }

    public void generateCode(BufferedWriter w) throws IOException{
        w.write("(");
        e1.generateCode(w);
        w.write(">");
        e2.generateCode(w);
        w.write(")");
    }
    
}
