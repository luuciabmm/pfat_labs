package AST;
import Errors.*;

import java.io.BufferedWriter;
import java.io.IOException;

public interface Decl {
    public void computeAh1() throws CompilerExc;
    public void generateCode(BufferedWriter w, int indentLevel) throws IOException;

}

