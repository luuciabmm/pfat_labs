package Errors;

public class DoubleDefExc extends CompilerExc {

    private String message;

    public DoubleDefExc(String message) {
       this.message = message;
         }
  
    public String toString() {
       return  "Error: DoubleDefExc" + this.message;
         }
    
}
