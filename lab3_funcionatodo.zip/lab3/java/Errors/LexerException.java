package Errors;

public class LexerException extends CompilerExc {

  private String message;

  public LexerException(String s) {
     message = s;
       }

  public String toString() {
     return message;
       }
}
