package Errors;

public class TypeExc extends CompilerExc{
    private String message;

    public TypeExc(String message){
        this.message = message;
    }

    public String toString(){
        return this.message;
    }
    
}


