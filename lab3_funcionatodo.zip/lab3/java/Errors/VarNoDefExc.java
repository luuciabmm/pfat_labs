package Errors;

public class VarNoDefExc extends CompilerExc{

    private String message;

    public VarNoDefExc(String message){
        this.message = message;
    }

    public String toString(){
        return "Error:VarNoDefExc" + this.message;
    }

    
}
