import parser.*;
import Lexer.*;
import java.io.*;

import AST.Prog;

public class Main
{
  public static void main(String args[]) throws Exception{
    java.io.BufferedReader in;
    Yylex sc;
    parser p;
    java_cup.runtime.Symbol sroot;
    boolean error=false;

    
    // p2 
    Prog raiz = null;

    //El primer parametro es el nombre del fichero con el programa
    if (args.length < 1) {
      System.out.println(
        "Uso: java Main <nombre_fichero>");
      error=true;
    }

    //p2Analisis lexico y sintactico
    if (!error) {  
      try {
          in = new java.io.BufferedReader(new java.io.FileReader(args[0]));
          sc = new Yylex(in);
          p = new parser(sc);

          //p1
          sroot = p.parse();
          System.out.println("Analisis lexico y sintactico correctos");

          //p2
          raiz = (Prog) sroot.value;
          raiz.computeAh1();
          raiz.computeTyp();
          System.out.println("Analisis Semantico correcto");
          
      } catch(IOException e) {
          System.out.println("Error abriendo fichero: " + args[0]);
          error= true;
      }
    }
    

    //p3- generación de código
    if(!error){
      try{
        File filename = new File(args[0]);
        String classname = filename.getName();
        if (classname.endsWith(".txt")) {
          classname = classname.substring(0, classname.length() - 4);
        }
        classname = classname.replaceAll("\\.", "_"); // Replace dots in filenames
        BufferedWriter w = new BufferedWriter(new FileWriter(classname + ".java"));

        w.write("import GeneratedCodeLib.*;\n");
        w.write("import Errors.*;\n");
        w.write("import java.util.Vector;\n");
        w.write("import java.util.Arrays;\n");

        w.write("public class " + classname + " {\n");
        w.write("  public static void main(String[] args) throws Exception {\n");
        w.write("    execute();");
        w.newLine();
        w.write("  }\n");
        
        raiz.generateCode(w, 0); // Generate the actual code from the AST
        w.write("}\n");

        w.close(); // Important to close the BufferedWriter to flush everything to file
        System.out.println("Generación de código completada exitosamente en " + classname + ".java");

      }catch(IOException e){
        System.out.println("Error abriendo fichero: " + args[0] + ".java");
        error = true;

      }
    }

  }
}


